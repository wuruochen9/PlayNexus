import "./history.css";
import { useState, useEffect } from 'react'  
import api from '../../api/axiosConfig'; 

const History = () => {
    const [users,setUsers] = useState([]);
    const [usergame,setUserGame] = useState([]);
    // var usergame;

    const getHistory =  async () =>{
      try{
        // Makes an API request to fetch a list of games and updates the games state variable with the response data.
        // debugger
        const response = await api.get('/api/v1/usergame');
        setUserGame(response.data);
        // usergame=response.data;
      }
      catch(err){
        console.log(err);
      }
    }

    useEffect(() => {getHistory();},[])
    // debugger
    return (
      <div >
          {usergame.map((game) => (
            <h1 className="gameTitle">
            <a href={`/Reviews/${game.GameID}`} className="gameName">{game.GameName}</a>
            <span className="timestamp">{new Date(game.Timestamp).toLocaleString()}</span>
          </h1>
            
          ))}
      </div>
    );
};

export default History;

