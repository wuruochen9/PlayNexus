import "./test.css";
import { useState, useEffect } from 'react'  
import { Link, useNavigate } from "react-router-dom"  
import api from '../../api/axiosConfig'; 

const Login = () => {
    const navigate = useNavigate();
    const [userName, setUserName] = useState("");
    const [userPwd, setUserPwd] = useState("");
    const [userEmail, setUserEmail] = useState("");
    const [userGender, setUserGender] = useState("");
    const [userAge, setUserAge] = useState("");
    
    const tryLogin = async () => {
      if (userName === '') {
        alert('Please enter your username');
      } 
      else if (userPwd === '') {
        alert('Please enter your password');
      } 
      else {
          try{
            const response = await api.post('/api/v1/login', { userName, userPwd,userEmail,userAge,userGender });
            debugger
            if("key" in response.data){
              sessionStorage.setItem("userkey", response.data["key"]);
              setUserName('');
              setUserPwd('');
              setUserEmail('');
              setUserGender('');
              setUserAge('');
              navigate(`/`);
            }
            else{
              alert(response.data);
            }
            // bmfzkkw
            // UK#f405m#&
          }
          catch(err){
              console.log(err);
              alert('Server Disconnected');
          }
      }
    };

    return (
      <div className="background" style={{ backgroundImage: `url("https://img.freepik.com/free-vector/hand-painted-watercolor-abstract-watercolor-background_52683-66117.jpg?w=996&t=st=1700201506~exp=1700202106~hmac=584b782e34941423408c68320c1a6cc5302e221bfaa19892876307aba99a814e")` }}>

          <section className="loginform cf">
              <section className="loginform_2 cf">
                  
                  <label className="label" htmlFor="username" >Username</label>
                  <input className="input" type="text" value={userName} onChange={(e) => setUserName(e.target.value)}  />
                  
                  <label htmlFor="password" className="label">Password</label>
                  <input className="input" type="password" value={userPwd} onChange={(e) => setUserPwd(e.target.value)} />

                  <label className="label" htmlFor="email" >Email</label>
                  <input className="input" type="email" value={userEmail} onChange={(e) => setUserEmail(e.target.value)}  />
                  
                  <label className="label" htmlFor="gender" >Gender</label>
                  <select className="input" value={userGender} onChange={(e) => setUserGender(e.target.value)}>
                      <option value="">Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                  </select>
                  
                  <label className="label" htmlFor="age" >Age</label>
                  <input className="input" type="number" value={userAge} onChange={(e) => setUserAge(e.target.value)}  />
                  
                  
                  
              </section>
              <section className="buttons cf">
            
                  <section>
                    <button type="submit" className="loginform_5 cf" onClick={() => tryLogin()}>Sign Up
                    </button>
                  </section>
              </section>
              

          </section>
      </div>
    );
};

export default Login;
