import React from 'react'; 
import { useState, useEffect } from 'react'         //This imports the useState and useEffect hooks from the React library.
import api from '../../api/axiosConfig';                //This assigns the export of axiosConfig.js to variable "api"

const Search = () => {
    return(
        <div></div>
    );
}

export default Search;